﻿namespace QLKTX
{
    partial class fr_dangky
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bt_dky = new System.Windows.Forms.Button();
            this.label_1 = new System.Windows.Forms.Label();
            this.txt_holot = new System.Windows.Forms.TextBox();
            this.txt_ten = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_sdt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_usename = new System.Windows.Forms.TextBox();
            this.date_brithday = new System.Windows.Forms.DateTimePicker();
            this.cb_loaitk = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label_loaitk = new System.Windows.Forms.Label();
            this.btn_reset = new System.Windows.Forms.Button();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.check_box_nam = new System.Windows.Forms.CheckBox();
            this.checkbox_nu = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_dchi = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cb_masv = new System.Windows.Forms.ComboBox();
            this.cb_nganhhoc = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(152, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Đăng ký thành viên";
            // 
            // bt_dky
            // 
            this.bt_dky.Location = new System.Drawing.Point(123, 426);
            this.bt_dky.Name = "bt_dky";
            this.bt_dky.Size = new System.Drawing.Size(75, 23);
            this.bt_dky.TabIndex = 1;
            this.bt_dky.Text = "Đăng kí";
            this.bt_dky.UseVisualStyleBackColor = true;
            this.bt_dky.Click += new System.EventHandler(this.bt_dky_Click);
            // 
            // label_1
            // 
            this.label_1.AutoSize = true;
            this.label_1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label_1.Location = new System.Drawing.Point(49, 68);
            this.label_1.Name = "label_1";
            this.label_1.Size = new System.Drawing.Size(35, 13);
            this.label_1.TabIndex = 2;
            this.label_1.Text = "Họ lót";
            this.label_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_holot
            // 
            this.txt_holot.Location = new System.Drawing.Point(100, 61);
            this.txt_holot.Name = "txt_holot";
            this.txt_holot.Size = new System.Drawing.Size(305, 20);
            this.txt_holot.TabIndex = 3;
            // 
            // txt_ten
            // 
            this.txt_ten.Location = new System.Drawing.Point(100, 103);
            this.txt_ten.Name = "txt_ten";
            this.txt_ten.Size = new System.Drawing.Size(305, 20);
            this.txt_ten.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label3.Location = new System.Drawing.Point(58, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tên";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label4.Location = new System.Drawing.Point(19, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Số điện thoại";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_sdt
            // 
            this.txt_sdt.Location = new System.Drawing.Point(100, 151);
            this.txt_sdt.Name = "txt_sdt";
            this.txt_sdt.Size = new System.Drawing.Size(305, 20);
            this.txt_sdt.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label5.Location = new System.Drawing.Point(34, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Username";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_usename
            // 
            this.txt_usename.Location = new System.Drawing.Point(100, 237);
            this.txt_usename.Name = "txt_usename";
            this.txt_usename.Size = new System.Drawing.Size(304, 20);
            this.txt_usename.TabIndex = 5;
            // 
            // date_brithday
            // 
            this.date_brithday.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date_brithday.Location = new System.Drawing.Point(100, 195);
            this.date_brithday.Name = "date_brithday";
            this.date_brithday.Size = new System.Drawing.Size(119, 20);
            this.date_brithday.TabIndex = 6;
            // 
            // cb_loaitk
            // 
            this.cb_loaitk.FormattingEnabled = true;
            this.cb_loaitk.Items.AddRange(new object[] {
            "Quản lý",
            "Sinh viên"});
            this.cb_loaitk.Location = new System.Drawing.Point(101, 322);
            this.cb_loaitk.Name = "cb_loaitk";
            this.cb_loaitk.Size = new System.Drawing.Size(303, 21);
            this.cb_loaitk.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label6.Location = new System.Drawing.Point(34, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Ngày sinh";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_loaitk
            // 
            this.label_loaitk.AutoSize = true;
            this.label_loaitk.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label_loaitk.Location = new System.Drawing.Point(14, 322);
            this.label_loaitk.Name = "label_loaitk";
            this.label_loaitk.Size = new System.Drawing.Size(74, 13);
            this.label_loaitk.TabIndex = 4;
            this.label_loaitk.Text = "Loại tài khoản";
            this.label_loaitk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(287, 426);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 1;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(101, 285);
            this.txt_password.Name = "txt_password";
            this.txt_password.PasswordChar = '*';
            this.txt_password.Size = new System.Drawing.Size(304, 20);
            this.txt_password.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label8.Location = new System.Drawing.Point(36, 285);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Mật khẩu";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // check_box_nam
            // 
            this.check_box_nam.AutoSize = true;
            this.check_box_nam.Checked = true;
            this.check_box_nam.CheckState = System.Windows.Forms.CheckState.Checked;
            this.check_box_nam.Location = new System.Drawing.Point(233, 197);
            this.check_box_nam.Name = "check_box_nam";
            this.check_box_nam.Size = new System.Drawing.Size(48, 17);
            this.check_box_nam.TabIndex = 12;
            this.check_box_nam.Text = "Nam";
            this.check_box_nam.UseVisualStyleBackColor = true;
            this.check_box_nam.CheckedChanged += new System.EventHandler(this.check_box_nam_CheckedChanged);
            // 
            // checkbox_nu
            // 
            this.checkbox_nu.AutoSize = true;
            this.checkbox_nu.Location = new System.Drawing.Point(287, 197);
            this.checkbox_nu.Name = "checkbox_nu";
            this.checkbox_nu.Size = new System.Drawing.Size(40, 17);
            this.checkbox_nu.TabIndex = 13;
            this.checkbox_nu.Text = "Nữ";
            this.checkbox_nu.UseVisualStyleBackColor = true;
            this.checkbox_nu.CheckedChanged += new System.EventHandler(this.checkbox_nu_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label2.Location = new System.Drawing.Point(45, 357);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Mã SV";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_dchi
            // 
            this.txt_dchi.Location = new System.Drawing.Point(100, 391);
            this.txt_dchi.Name = "txt_dchi";
            this.txt_dchi.Size = new System.Drawing.Size(305, 20);
            this.txt_dchi.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label9.Location = new System.Drawing.Point(32, 391);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Địa Chỉ";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(198, 358);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Nghành học";
            // 
            // cb_masv
            // 
            this.cb_masv.FormattingEnabled = true;
            this.cb_masv.Items.AddRange(new object[] {
            "Quản lý",
            "Sinh viên"});
            this.cb_masv.Location = new System.Drawing.Point(100, 355);
            this.cb_masv.Name = "cb_masv";
            this.cb_masv.Size = new System.Drawing.Size(82, 21);
            this.cb_masv.TabIndex = 20;
            // 
            // cb_nganhhoc
            // 
            this.cb_nganhhoc.FormattingEnabled = true;
            this.cb_nganhhoc.Items.AddRange(new object[] {
            "Quản lý",
            "Sinh viên"});
            this.cb_nganhhoc.Location = new System.Drawing.Point(270, 353);
            this.cb_nganhhoc.Name = "cb_nganhhoc";
            this.cb_nganhhoc.Size = new System.Drawing.Size(135, 21);
            this.cb_nganhhoc.TabIndex = 21;
            // 
            // fr_dangky
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(434, 461);
            this.Controls.Add(this.cb_nganhhoc);
            this.Controls.Add(this.cb_masv);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_dchi);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkbox_nu);
            this.Controls.Add(this.check_box_nam);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cb_loaitk);
            this.Controls.Add(this.date_brithday);
            this.Controls.Add(this.txt_usename);
            this.Controls.Add(this.txt_sdt);
            this.Controls.Add(this.txt_ten);
            this.Controls.Add(this.label_loaitk);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_holot);
            this.Controls.Add(this.label_1);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.bt_dky);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(450, 500);
            this.Name = "fr_dangky";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đăng ký tài khoản";
            this.Load += new System.EventHandler(this.fr_dangky_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_dky;
        private System.Windows.Forms.Label label_1;
        private System.Windows.Forms.TextBox txt_holot;
        private System.Windows.Forms.TextBox txt_ten;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_sdt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_usename;
        private System.Windows.Forms.DateTimePicker date_brithday;
        private System.Windows.Forms.ComboBox cb_loaitk;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label_loaitk;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox check_box_nam;
        private System.Windows.Forms.CheckBox checkbox_nu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_dchi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cb_masv;
        private System.Windows.Forms.ComboBox cb_nganhhoc;
    }
}