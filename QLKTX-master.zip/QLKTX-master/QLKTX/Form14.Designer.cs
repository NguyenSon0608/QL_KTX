﻿
namespace QLKTX
{
    partial class Form14
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btntimkiem = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnhuy = new System.Windows.Forms.Button();
            this.btnluu = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpngaydong = new System.Windows.Forms.DateTimePicker();
            this.txtthang = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnthoat = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btnsua = new System.Windows.Forms.Button();
            this.btnthemmoi = new System.Windows.Forms.Button();
            this.dtgrdvsinhvien = new System.Windows.Forms.DataGridView();
            this.cbxTKMP = new System.Windows.Forms.ComboBox();
            this.cbxmaphong = new System.Windows.Forms.ComboBox();
            this.txttiendien = new System.Windows.Forms.TextBox();
            this.txttiennha = new System.Windows.Forms.TextBox();
            this.txtnam = new System.Windows.Forms.TextBox();
            this.txttiennuoc = new System.Windows.Forms.TextBox();
            this.txttienvesinh = new System.Windows.Forms.TextBox();
            this.txttienphat = new System.Windows.Forms.TextBox();
            this.dtpngayHH = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrdvsinhvien)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbxTKMP);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.btntimkiem);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 45);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(554, 70);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "TÌM KIẾM";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(30, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 17);
            this.label10.TabIndex = 15;
            this.label10.Text = "Mã Phòng";
            // 
            // btntimkiem
            // 
            this.btntimkiem.Location = new System.Drawing.Point(409, 27);
            this.btntimkiem.Name = "btntimkiem";
            this.btntimkiem.Size = new System.Drawing.Size(75, 23);
            this.btntimkiem.TabIndex = 12;
            this.btntimkiem.Text = "Tìm &Kiếm";
            this.btntimkiem.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label9);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(554, 45);
            this.panel2.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(154, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(173, 25);
            this.label9.TabIndex = 0;
            this.label9.Text = "CHI PHÍ PHÒNG";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.dtpngayHH);
            this.groupBox1.Controls.Add(this.txttienphat);
            this.groupBox1.Controls.Add(this.txttienvesinh);
            this.groupBox1.Controls.Add(this.txttiennuoc);
            this.groupBox1.Controls.Add(this.txtnam);
            this.groupBox1.Controls.Add(this.txttiennha);
            this.groupBox1.Controls.Add(this.txttiendien);
            this.groupBox1.Controls.Add(this.cbxmaphong);
            this.groupBox1.Controls.Add(this.btnhuy);
            this.groupBox1.Controls.Add(this.btnluu);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.dtpngaydong);
            this.groupBox1.Controls.Add(this.txtthang);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(554, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(272, 460);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            // 
            // btnhuy
            // 
            this.btnhuy.Location = new System.Drawing.Point(185, 424);
            this.btnhuy.Name = "btnhuy";
            this.btnhuy.Size = new System.Drawing.Size(75, 32);
            this.btnhuy.TabIndex = 26;
            this.btnhuy.Text = "&Huỷ";
            this.btnhuy.UseVisualStyleBackColor = true;
            // 
            // btnluu
            // 
            this.btnluu.Location = new System.Drawing.Point(9, 424);
            this.btnluu.Name = "btnluu";
            this.btnluu.Size = new System.Drawing.Size(75, 32);
            this.btnluu.TabIndex = 25;
            this.btnluu.Text = "&Lưu";
            this.btnluu.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 372);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 17);
            this.label8.TabIndex = 22;
            this.label8.Text = "Ngày Đóng";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 95);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 17);
            this.label7.TabIndex = 20;
            this.label7.Text = "Năm";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 17);
            this.label6.TabIndex = 19;
            this.label6.Text = "Tiền Nước";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 17);
            this.label5.TabIndex = 18;
            this.label5.Text = "Mã Phòng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 17);
            this.label4.TabIndex = 17;
            this.label4.Text = "Tiền Vệ Sinh";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 16;
            this.label3.Text = "Tiền Điện";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 17);
            this.label2.TabIndex = 15;
            this.label2.Text = "Tiền Nhà ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 14;
            this.label1.Text = "Tháng";
            // 
            // dtpngaydong
            // 
            this.dtpngaydong.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpngaydong.Location = new System.Drawing.Point(94, 367);
            this.dtpngaydong.Name = "dtpngaydong";
            this.dtpngaydong.Size = new System.Drawing.Size(159, 23);
            this.dtpngaydong.TabIndex = 8;
            // 
            // txtthang
            // 
            this.txtthang.Location = new System.Drawing.Point(93, 58);
            this.txtthang.Name = "txtthang";
            this.txtthang.Size = new System.Drawing.Size(160, 23);
            this.txtthang.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnthoat);
            this.panel1.Controls.Add(this.btnxoa);
            this.panel1.Controls.Add(this.btnsua);
            this.panel1.Controls.Add(this.btnthemmoi);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 460);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(826, 45);
            this.panel1.TabIndex = 8;
            // 
            // btnthoat
            // 
            this.btnthoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnthoat.Location = new System.Drawing.Point(665, 7);
            this.btnthoat.Name = "btnthoat";
            this.btnthoat.Size = new System.Drawing.Size(76, 32);
            this.btnthoat.TabIndex = 16;
            this.btnthoat.Text = "&Thoát";
            this.btnthoat.UseVisualStyleBackColor = true;
            // 
            // btnxoa
            // 
            this.btnxoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnxoa.Location = new System.Drawing.Point(451, 6);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(81, 33);
            this.btnxoa.TabIndex = 15;
            this.btnxoa.Text = "&Xoá";
            this.btnxoa.UseVisualStyleBackColor = true;
            // 
            // btnsua
            // 
            this.btnsua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsua.Location = new System.Drawing.Point(239, 7);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(88, 33);
            this.btnsua.TabIndex = 14;
            this.btnsua.Text = "&Sửa";
            this.btnsua.UseVisualStyleBackColor = true;
            // 
            // btnthemmoi
            // 
            this.btnthemmoi.BackColor = System.Drawing.Color.MediumTurquoise;
            this.btnthemmoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnthemmoi.Location = new System.Drawing.Point(58, 7);
            this.btnthemmoi.Name = "btnthemmoi";
            this.btnthemmoi.Size = new System.Drawing.Size(80, 33);
            this.btnthemmoi.TabIndex = 13;
            this.btnthemmoi.Text = "Thêm &Mới";
            this.btnthemmoi.UseVisualStyleBackColor = false;
            // 
            // dtgrdvsinhvien
            // 
            this.dtgrdvsinhvien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgrdvsinhvien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtgrdvsinhvien.Location = new System.Drawing.Point(0, 0);
            this.dtgrdvsinhvien.Name = "dtgrdvsinhvien";
            this.dtgrdvsinhvien.Size = new System.Drawing.Size(826, 505);
            this.dtgrdvsinhvien.TabIndex = 7;
            // 
            // cbxTKMP
            // 
            this.cbxTKMP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTKMP.FormattingEnabled = true;
            this.cbxTKMP.Location = new System.Drawing.Point(123, 26);
            this.cbxTKMP.Name = "cbxTKMP";
            this.cbxTKMP.Size = new System.Drawing.Size(204, 24);
            this.cbxTKMP.TabIndex = 25;
            // 
            // cbxmaphong
            // 
            this.cbxmaphong.FormattingEnabled = true;
            this.cbxmaphong.Location = new System.Drawing.Point(93, 21);
            this.cbxmaphong.Name = "cbxmaphong";
            this.cbxmaphong.Size = new System.Drawing.Size(159, 24);
            this.cbxmaphong.TabIndex = 27;
            // 
            // txttiendien
            // 
            this.txttiendien.Location = new System.Drawing.Point(94, 172);
            this.txttiendien.Name = "txttiendien";
            this.txttiendien.Size = new System.Drawing.Size(160, 23);
            this.txttiendien.TabIndex = 28;
            // 
            // txttiennha
            // 
            this.txttiennha.Location = new System.Drawing.Point(94, 131);
            this.txttiennha.Name = "txttiennha";
            this.txttiennha.Size = new System.Drawing.Size(160, 23);
            this.txttiennha.TabIndex = 29;
            // 
            // txtnam
            // 
            this.txtnam.Location = new System.Drawing.Point(94, 92);
            this.txtnam.Name = "txtnam";
            this.txtnam.Size = new System.Drawing.Size(160, 23);
            this.txtnam.TabIndex = 30;
            // 
            // txttiennuoc
            // 
            this.txttiennuoc.Location = new System.Drawing.Point(94, 213);
            this.txttiennuoc.Name = "txttiennuoc";
            this.txttiennuoc.Size = new System.Drawing.Size(160, 23);
            this.txttiennuoc.TabIndex = 31;
            // 
            // txttienvesinh
            // 
            this.txttienvesinh.Location = new System.Drawing.Point(94, 249);
            this.txttienvesinh.Name = "txttienvesinh";
            this.txttienvesinh.Size = new System.Drawing.Size(160, 23);
            this.txttienvesinh.TabIndex = 32;
            // 
            // txttienphat
            // 
            this.txttienphat.Location = new System.Drawing.Point(94, 290);
            this.txttienphat.Name = "txttienphat";
            this.txttienphat.Size = new System.Drawing.Size(160, 23);
            this.txttienphat.TabIndex = 33;
            // 
            // dtpngayHH
            // 
            this.dtpngayHH.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpngayHH.Location = new System.Drawing.Point(94, 328);
            this.dtpngayHH.Name = "dtpngayHH";
            this.dtpngayHH.Size = new System.Drawing.Size(159, 23);
            this.dtpngayHH.TabIndex = 34;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 293);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 17);
            this.label11.TabIndex = 35;
            this.label11.Text = "Tiền Phạt";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 333);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 17);
            this.label12.TabIndex = 36;
            this.label12.Text = "Hết Hạn";
            // 
            // Form14
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.ClientSize = new System.Drawing.Size(826, 505);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dtgrdvsinhvien);
            this.Name = "Form14";
            this.Text = "CHI PHÍ PHÒNG";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgrdvsinhvien)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbxTKMP;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btntimkiem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtpngayHH;
        private System.Windows.Forms.TextBox txttienphat;
        private System.Windows.Forms.TextBox txttienvesinh;
        private System.Windows.Forms.TextBox txttiennuoc;
        private System.Windows.Forms.TextBox txtnam;
        private System.Windows.Forms.TextBox txttiennha;
        private System.Windows.Forms.TextBox txttiendien;
        private System.Windows.Forms.ComboBox cbxmaphong;
        private System.Windows.Forms.Button btnhuy;
        private System.Windows.Forms.Button btnluu;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpngaydong;
        private System.Windows.Forms.TextBox txtthang;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnthoat;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button btnthemmoi;
        private System.Windows.Forms.DataGridView dtgrdvsinhvien;
    }
}