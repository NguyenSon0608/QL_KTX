﻿
namespace QLKTX
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnspquanli = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThiếtBịToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.chiPhíPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnspdanhmuc = new System.Windows.Forms.ToolStripMenuItem();
            this.khoaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lớpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thiếtBịToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khuNhàToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmnLienhe = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsptuychon = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnspquanli,
            this.mnspdanhmuc,
            this.tsmnLienhe,
            this.mnsptuychon});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(710, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnspquanli
            // 
            this.mnspquanli.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinSinhViênToolStripMenuItem,
            this.quảnLýPhòngToolStripMenuItem,
            this.quảnLýToolStripMenuItem,
            this.quảnLýThiếtBịToolStripMenuItem,
            this.quảnLýToolStripMenuItem1,
            this.chiPhíPhòngToolStripMenuItem});
            this.mnspquanli.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnspquanli.Image = ((System.Drawing.Image)(resources.GetObject("mnspquanli.Image")));
            this.mnspquanli.Name = "mnspquanli";
            this.mnspquanli.Size = new System.Drawing.Size(87, 21);
            this.mnspquanli.Text = "Quản Lý";
            // 
            // thôngTinSinhViênToolStripMenuItem
            // 
            this.thôngTinSinhViênToolStripMenuItem.Name = "thôngTinSinhViênToolStripMenuItem";
            this.thôngTinSinhViênToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.thôngTinSinhViênToolStripMenuItem.Text = "Thông Tin Sinh Viên";
            this.thôngTinSinhViênToolStripMenuItem.Click += new System.EventHandler(this.thôngTinSinhViênToolStripMenuItem_Click);
            // 
            // quảnLýPhòngToolStripMenuItem
            // 
            this.quảnLýPhòngToolStripMenuItem.Name = "quảnLýPhòngToolStripMenuItem";
            this.quảnLýPhòngToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.quảnLýPhòngToolStripMenuItem.Text = "Quản Lý Phòng";
            this.quảnLýPhòngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýPhòngToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.quảnLýToolStripMenuItem.Text = "Quản Lý Thuê Phòng";
            this.quảnLýToolStripMenuItem.Click += new System.EventHandler(this.quảnLýToolStripMenuItem_Click);
            // 
            // quảnLýThiếtBịToolStripMenuItem
            // 
            this.quảnLýThiếtBịToolStripMenuItem.Name = "quảnLýThiếtBịToolStripMenuItem";
            this.quảnLýThiếtBịToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.quảnLýThiếtBịToolStripMenuItem.Text = "Quản Lý Thiết Bị";
            this.quảnLýThiếtBịToolStripMenuItem.Click += new System.EventHandler(this.quảnLýThiếtBịToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem1
            // 
            this.quảnLýToolStripMenuItem1.Name = "quảnLýToolStripMenuItem1";
            this.quảnLýToolStripMenuItem1.Size = new System.Drawing.Size(206, 22);
            this.quảnLýToolStripMenuItem1.Text = "Quản Lý Trả Phòng";
            this.quảnLýToolStripMenuItem1.Click += new System.EventHandler(this.quảnLýToolStripMenuItem1_Click);
            // 
            // chiPhíPhòngToolStripMenuItem
            // 
            this.chiPhíPhòngToolStripMenuItem.Name = "chiPhíPhòngToolStripMenuItem";
            this.chiPhíPhòngToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.chiPhíPhòngToolStripMenuItem.Text = "Chi Phí Phòng";
            this.chiPhíPhòngToolStripMenuItem.Click += new System.EventHandler(this.chiPhíPhòngToolStripMenuItem_Click);
            // 
            // mnspdanhmuc
            // 
            this.mnspdanhmuc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.khoaToolStripMenuItem,
            this.lớpToolStripMenuItem,
            this.quêToolStripMenuItem,
            this.thiếtBịToolStripMenuItem,
            this.khuNhàToolStripMenuItem});
            this.mnspdanhmuc.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnspdanhmuc.Image = ((System.Drawing.Image)(resources.GetObject("mnspdanhmuc.Image")));
            this.mnspdanhmuc.Name = "mnspdanhmuc";
            this.mnspdanhmuc.Size = new System.Drawing.Size(99, 21);
            this.mnspdanhmuc.Text = "Danh Mục";
            // 
            // khoaToolStripMenuItem
            // 
            this.khoaToolStripMenuItem.Name = "khoaToolStripMenuItem";
            this.khoaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.khoaToolStripMenuItem.Text = "Khoa";
            this.khoaToolStripMenuItem.Click += new System.EventHandler(this.khoaToolStripMenuItem_Click);
            // 
            // lớpToolStripMenuItem
            // 
            this.lớpToolStripMenuItem.Name = "lớpToolStripMenuItem";
            this.lớpToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.lớpToolStripMenuItem.Text = "Lớp";
            this.lớpToolStripMenuItem.Click += new System.EventHandler(this.lớpToolStripMenuItem_Click);
            // 
            // quêToolStripMenuItem
            // 
            this.quêToolStripMenuItem.Name = "quêToolStripMenuItem";
            this.quêToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.quêToolStripMenuItem.Text = "Quê";
            this.quêToolStripMenuItem.Click += new System.EventHandler(this.quêToolStripMenuItem_Click);
            // 
            // thiếtBịToolStripMenuItem
            // 
            this.thiếtBịToolStripMenuItem.Name = "thiếtBịToolStripMenuItem";
            this.thiếtBịToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.thiếtBịToolStripMenuItem.Text = "Thiết Bị";
            this.thiếtBịToolStripMenuItem.Click += new System.EventHandler(this.thiếtBịToolStripMenuItem_Click);
            // 
            // khuNhàToolStripMenuItem
            // 
            this.khuNhàToolStripMenuItem.Name = "khuNhàToolStripMenuItem";
            this.khuNhàToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.khuNhàToolStripMenuItem.Text = "Khu Nhà";
            this.khuNhàToolStripMenuItem.Click += new System.EventHandler(this.khuNhàToolStripMenuItem_Click);
            // 
            // tsmnLienhe
            // 
            this.tsmnLienhe.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmnLienhe.Image = global::QLKTX.Properties.Resources._257536464_244243767694010_1524361552359720052_n;
            this.tsmnLienhe.Name = "tsmnLienhe";
            this.tsmnLienhe.Size = new System.Drawing.Size(83, 21);
            this.tsmnLienhe.Text = "Liên Hệ";
            this.tsmnLienhe.Click += new System.EventHandler(this.tsmnLienhe_Click);
            // 
            // mnsptuychon
            // 
            this.mnsptuychon.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đăngXuấtToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.mnsptuychon.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnsptuychon.Image = ((System.Drawing.Image)(resources.GetObject("mnsptuychon.Image")));
            this.mnsptuychon.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.mnsptuychon.Name = "mnsptuychon";
            this.mnsptuychon.Size = new System.Drawing.Size(94, 21);
            this.mnsptuychon.Text = "Tuỳ Chọn";
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng Xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.BackgroundImage = global::QLKTX.Properties.Resources._245602780_302560874784625_3122522892384774950_n;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(710, 389);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.Text = "Quản Lí Kí Túc Xá";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnspquanli;
        private System.Windows.Forms.ToolStripMenuItem mnspdanhmuc;
        private System.Windows.Forms.ToolStripMenuItem tsmnLienhe;
        private System.Windows.Forms.ToolStripMenuItem mnsptuychon;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThiếtBịToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem chiPhíPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khoaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lớpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thiếtBịToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khuNhàToolStripMenuItem;
    }
}