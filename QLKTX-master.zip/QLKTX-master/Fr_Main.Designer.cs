﻿
namespace QLKTX
{
    partial class Fr_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fr_Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnspquanli = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThuePhongStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýThiếtBịToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýtra_phongtripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.chiPhíPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnspdanhmuc = new System.Windows.Forms.ToolStripMenuItem();
            this.khoaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lớpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thiếtBịToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khuNhàToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmnLienhe = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsptuychon = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tạoTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblchu = new System.Windows.Forms.Label();
            this.label_xinchao = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnspquanli,
            this.mnspdanhmuc,
            this.tsmnLienhe,
            this.mnsptuychon});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(710, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnspquanli
            // 
            this.mnspquanli.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinSinhViênToolStripMenuItem,
            this.quảnLýPhòngToolStripMenuItem,
            this.quảnLýThuePhongStripMenuItem,
            this.quảnLýThiếtBịToolStripMenuItem,
            this.quảnLýtra_phongtripMenuItem1,
            this.chiPhíPhòngToolStripMenuItem});
            this.mnspquanli.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnspquanli.Image = ((System.Drawing.Image)(resources.GetObject("mnspquanli.Image")));
            this.mnspquanli.Name = "mnspquanli";
            this.mnspquanli.Size = new System.Drawing.Size(87, 21);
            this.mnspquanli.Text = "Quản Lý";
            // 
            // thôngTinSinhViênToolStripMenuItem
            // 
            this.thôngTinSinhViênToolStripMenuItem.Name = "thôngTinSinhViênToolStripMenuItem";
            this.thôngTinSinhViênToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.thôngTinSinhViênToolStripMenuItem.Text = "Thông Tin Sinh Viên";
            this.thôngTinSinhViênToolStripMenuItem.Click += new System.EventHandler(this.thôngTinSinhViênToolStripMenuItem_Click);
            // 
            // quảnLýPhòngToolStripMenuItem
            // 
            this.quảnLýPhòngToolStripMenuItem.Name = "quảnLýPhòngToolStripMenuItem";
            this.quảnLýPhòngToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.quảnLýPhòngToolStripMenuItem.Text = "Quản Lý Phòng";
            this.quảnLýPhòngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýPhòngToolStripMenuItem_Click);
            // 
            // quảnLýThuePhongStripMenuItem
            // 
            this.quảnLýThuePhongStripMenuItem.Name = "quảnLýThuePhongStripMenuItem";
            this.quảnLýThuePhongStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.quảnLýThuePhongStripMenuItem.Text = "Quản Lý Thuê Phòng";
            this.quảnLýThuePhongStripMenuItem.Click += new System.EventHandler(this.quảnLýToolStripMenuItem_Click);
            // 
            // quảnLýThiếtBịToolStripMenuItem
            // 
            this.quảnLýThiếtBịToolStripMenuItem.Name = "quảnLýThiếtBịToolStripMenuItem";
            this.quảnLýThiếtBịToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.quảnLýThiếtBịToolStripMenuItem.Text = "Quản Lý Thiết Bị";
            this.quảnLýThiếtBịToolStripMenuItem.Click += new System.EventHandler(this.quảnLýThiếtBịToolStripMenuItem_Click);
            // 
            // quảnLýtra_phongtripMenuItem1
            // 
            this.quảnLýtra_phongtripMenuItem1.Name = "quảnLýtra_phongtripMenuItem1";
            this.quảnLýtra_phongtripMenuItem1.Size = new System.Drawing.Size(206, 22);
            this.quảnLýtra_phongtripMenuItem1.Text = "Quản Lý Trả Phòng";
            this.quảnLýtra_phongtripMenuItem1.Click += new System.EventHandler(this.quảnLýToolStripMenuItem1_Click);
            // 
            // chiPhíPhòngToolStripMenuItem
            // 
            this.chiPhíPhòngToolStripMenuItem.Name = "chiPhíPhòngToolStripMenuItem";
            this.chiPhíPhòngToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.chiPhíPhòngToolStripMenuItem.Text = "Chi Phí Phòng";
            this.chiPhíPhòngToolStripMenuItem.Click += new System.EventHandler(this.chiPhíPhòngToolStripMenuItem_Click);
            // 
            // mnspdanhmuc
            // 
            this.mnspdanhmuc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.khoaToolStripMenuItem,
            this.lớpToolStripMenuItem,
            this.quêToolStripMenuItem,
            this.thiếtBịToolStripMenuItem,
            this.khuNhàToolStripMenuItem});
            this.mnspdanhmuc.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnspdanhmuc.Image = ((System.Drawing.Image)(resources.GetObject("mnspdanhmuc.Image")));
            this.mnspdanhmuc.Name = "mnspdanhmuc";
            this.mnspdanhmuc.Size = new System.Drawing.Size(99, 21);
            this.mnspdanhmuc.Text = "Danh Mục";
            // 
            // khoaToolStripMenuItem
            // 
            this.khoaToolStripMenuItem.Name = "khoaToolStripMenuItem";
            this.khoaToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.khoaToolStripMenuItem.Text = "Khoa";
            this.khoaToolStripMenuItem.Click += new System.EventHandler(this.khoaToolStripMenuItem_Click);
            // 
            // lớpToolStripMenuItem
            // 
            this.lớpToolStripMenuItem.Name = "lớpToolStripMenuItem";
            this.lớpToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.lớpToolStripMenuItem.Text = "Lớp";
            this.lớpToolStripMenuItem.Click += new System.EventHandler(this.lớpToolStripMenuItem_Click);
            // 
            // quêToolStripMenuItem
            // 
            this.quêToolStripMenuItem.Name = "quêToolStripMenuItem";
            this.quêToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.quêToolStripMenuItem.Text = "Quê";
            this.quêToolStripMenuItem.Click += new System.EventHandler(this.quêToolStripMenuItem_Click);
            // 
            // thiếtBịToolStripMenuItem
            // 
            this.thiếtBịToolStripMenuItem.Name = "thiếtBịToolStripMenuItem";
            this.thiếtBịToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.thiếtBịToolStripMenuItem.Text = "Thiết Bị";
            this.thiếtBịToolStripMenuItem.Click += new System.EventHandler(this.thiếtBịToolStripMenuItem_Click);
            // 
            // khuNhàToolStripMenuItem
            // 
            this.khuNhàToolStripMenuItem.Name = "khuNhàToolStripMenuItem";
            this.khuNhàToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.khuNhàToolStripMenuItem.Text = "Khu Nhà";
            this.khuNhàToolStripMenuItem.Click += new System.EventHandler(this.khuNhàToolStripMenuItem_Click);
            // 
            // tsmnLienhe
            // 
            this.tsmnLienhe.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmnLienhe.Image = ((System.Drawing.Image)(resources.GetObject("tsmnLienhe.Image")));
            this.tsmnLienhe.Name = "tsmnLienhe";
            this.tsmnLienhe.Size = new System.Drawing.Size(83, 21);
            this.tsmnLienhe.Text = "Liên Hệ";
            this.tsmnLienhe.Click += new System.EventHandler(this.tsmnLienhe_Click);
            // 
            // mnsptuychon
            // 
            this.mnsptuychon.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đăngXuấtToolStripMenuItem,
            this.thoátToolStripMenuItem,
            this.tạoTàiKhoảnToolStripMenuItem});
            this.mnsptuychon.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnsptuychon.Image = ((System.Drawing.Image)(resources.GetObject("mnsptuychon.Image")));
            this.mnsptuychon.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.mnsptuychon.Name = "mnsptuychon";
            this.mnsptuychon.Size = new System.Drawing.Size(94, 21);
            this.mnsptuychon.Text = "Tuỳ Chọn";
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng Xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // tạoTàiKhoảnToolStripMenuItem
            // 
            this.tạoTàiKhoảnToolStripMenuItem.Name = "tạoTàiKhoảnToolStripMenuItem";
            this.tạoTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.tạoTàiKhoảnToolStripMenuItem.Text = "Tạo Tài khoản";
            this.tạoTàiKhoảnToolStripMenuItem.Click += new System.EventHandler(this.tạoTàiKhoảnToolStripMenuItem_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblchu
            // 
            this.lblchu.AutoSize = true;
            this.lblchu.BackColor = System.Drawing.Color.Transparent;
            this.lblchu.Font = new System.Drawing.Font("Stencil", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchu.ForeColor = System.Drawing.Color.Yellow;
            this.lblchu.Location = new System.Drawing.Point(169, 70);
            this.lblchu.Name = "lblchu";
            this.lblchu.Size = new System.Drawing.Size(423, 32);
            this.lblchu.TabIndex = 1;
            this.lblchu.Text = "QUẢN LÝ KÍ TÚC XÁ SINH VIÊN";
            // 
            // label_xinchao
            // 
            this.label_xinchao.AutoSize = true;
            this.label_xinchao.BackColor = System.Drawing.Color.White;
            this.label_xinchao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_xinchao.Location = new System.Drawing.Point(490, 5);
            this.label_xinchao.Name = "label_xinchao";
            this.label_xinchao.Size = new System.Drawing.Size(73, 17);
            this.label_xinchao.TabIndex = 2;
            this.label_xinchao.Text = "Xin Chào";
            // 
            // Fr_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(710, 389);
            this.Controls.Add(this.label_xinchao);
            this.Controls.Add(this.lblchu);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Fr_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lí Kí Túc Xá";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnspquanli;
        private System.Windows.Forms.ToolStripMenuItem mnspdanhmuc;
        private System.Windows.Forms.ToolStripMenuItem tsmnLienhe;
        private System.Windows.Forms.ToolStripMenuItem mnsptuychon;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThuePhongStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýThiếtBịToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýtra_phongtripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem chiPhíPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khoaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lớpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thiếtBịToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khuNhàToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblchu;
        private System.Windows.Forms.ToolStripMenuItem tạoTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.Label label_xinchao;
    }
}